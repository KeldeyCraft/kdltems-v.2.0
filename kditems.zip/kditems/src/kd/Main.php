<?php
/**
 * Created by PhpStorm.
 * User: kd
 * Date: 10/08/2018
 * Time: 14:49
 */
namespace kd;

use pocketmine\entity\Effect;
use pocketmine\entity\EffectInstance;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerRespawnEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\Item;
use pocketmine\level\sound\EndermanTeleportSound;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;
use pocketmine\network\mcpe\protocol\TransferPacket;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\TextFormat as T;

class Main extends PluginBase implements Listener{
    
    public function onEnable()
    {
        $this->getServer()->getLogger()->info("§aKDITEMS §4IS NOW ON!");
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onDisable()
    {
        $this->getServer()->getLogger()->info("§aKDITEMS §4 IS NOW OFF");
    }

    public function onGiveItems(Player $player)
    {
        $inv = $player->getInventory();

        #Itemes List
        $item[0] = Item::get(Item::EMERALD, 0, 1)->setCustomName(T::RED . "Speed {rightclick}");
        $item[1] = Item::get(Item::PAPER, 0, 1)->setCustomName(T::RED . "Rules {rightclick}");
        $item[2] = Item::get(Item::COMPASS, 0, 1)->setCustomName(T::RED . "SERVER TELEPORTER {rightclick}");

        /*
         * Set player inventory tools
         */
        $inv->setItem(2, $item[0]); //1 speed
        $inv->setItem(4, $item[1]); //2 info
        $inv->setItem(6, $item[2]); //4 selector
        $inv->sendContents($player);
    }

    public function onJoin(PlayerJoinEvent $e)
    {
        $player = $e->getPlayer();
        $this->onGiveItems($player);
    }

    public function onRespawn(PlayerRespawnEvent $e)
    {
        $player = $e->getPlayer();
        $this->onGiveItems($player);
    }

    public function onInteract(PlayerInteractEvent $e)
    {
        $player = $e->getPlayer();
        $item = $e->getItem();
        $action = $e->getAction();
        $itemID = $item->getId();

        if ($action === PlayerInteractEvent::RIGHT_CLICK_AIR)
        {
            switch ($itemID)
            {
                case Item::EMERALD:

                    if ($player->getEffect(Effect::SPEED))
                    {
                        $player->removeEffect(Effect::SPEED);
                        $player->getLevel()->addSound(new EndermanTeleportSound($player));
                    }else{
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 10000, 3, false));
                        $player->getLevel()->addSound(new EndermanTeleportSound($player));
                    }
                    break;

                case Item::PAPER:

                    $pk = new ModalFormRequestPacket();
                    $pk->formId = 2;
                    $form["title"] = T::AQUA . "Network Rules";
                    $form["type"] = "form";
                    $form["content"] = T::GOLD . "==================\n" . T::RED . "No Spam\nNo insult\nNo cheats\n" . T::GOLD . "==================";
                    $form["buttons"] = array(array("text" => "Exit"));

                    $pk->formData = json_encode($form);
                    $player->dataPacket($pk);
                    break;

                case Item::COMPASS:

                    $pk = new ModalFormRequestPacket();
                    $pk->formId = 1;
                    $form["title"] = "Server Teleporter";
                    $form["type"] = "form";
                    $form["content"] = T::RED . "Select a server";
                    $form["buttons"] = array(array("text" => T::YELLOW . "§l§b...\n..."), array("text" => T::YELLOW . "§l§b...\n§4..."), array("text" => T::YELLOW . "§l§b...\n..."));

                    $pk->formData = json_encode($form);
                    $player->dataPacket($pk);
                    break;
            }
        }
    }

    public function onDrop(PlayerDropItemEvent $e)
    {
        $item = $e->getItem();
        $itemID = $item->getId();

        switch ($itemID)
        {
            case Item::EMERALD:
                $e->setCancelled();
                break;

            case Item::COMPASS:
                $e->setCancelled();
                break;

            case Item::PAPER:
                $e->setCancelled();
                break;
        }
    }

    public function onDataPacket(DataPacketReceiveEvent $e)
    {
        $pk = $e->getPacket();
        $player = $e->getPlayer();

        if ($pk instanceof ModalFormResponsePacket) {
            $data = json_decode($pk->formData);
            if ($data != null) {
                if ($pk->formId == 1) {
                    if ($pk->formData != null) {
                        switch ($pk->formData[0]) {
                            case 0:

                                $pk = new TransferPacket();
                                $pk->address = "sethereyourip.tk";
                                $pk->port = 19133;
                                $player->dataPacket($pk);
                                break;

                            case 1:

                                $pk = new TransferPacket();
                                $pk->address = "sethereyourip.tk";
                                $pk->port = 19134;
                                $player->dataPacket($pk);
                                break;

                            case 2:

                                $pk = new TransferPacket();
                                $pk->address = "sethereyourip.tk";
                                $pk->port = 19135;
                                $player->dataPacket($pk);
                                break;

                        }
                    }
                }
            }
        }
    }
}